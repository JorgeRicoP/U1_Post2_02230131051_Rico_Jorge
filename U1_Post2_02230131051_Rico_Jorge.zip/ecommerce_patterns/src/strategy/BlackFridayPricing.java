package strategy;

public class BlackFridayPricing implements PricingStrategy{
	public double calculateFinalPrice(double price) {
		return price *= 0.70;
	}
	
	public String getDescription() { 
		return "Precio ÚNICO por promocion de Black Friday (30%)"; 
	}
}

