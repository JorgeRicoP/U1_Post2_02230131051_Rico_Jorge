package strategy;

public class BulkPricing implements PricingStrategy {
	
	private int quantity;
	
	public BulkPricing(int quantity) {
		this.quantity = quantity;
	}
	
	public double calculateFinalPrice(double price) {
		if (quantity>=10) {
			return price *= 0.80;
		}
		return price;
	}
	
	public String getDescription() { 
		return "Precio ÚNICO por compra grande (20%)"; 
	}
}

