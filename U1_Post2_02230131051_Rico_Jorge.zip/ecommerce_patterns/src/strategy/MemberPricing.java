package strategy;

public class MemberPricing implements PricingStrategy{
	public double calculateFinalPrice(double price) {
		return price *= 0.90;
	}
	
	public String getDescription() { 
		return "Precio ÚNICO para miembros VIP (10%)"; 
	}
}

