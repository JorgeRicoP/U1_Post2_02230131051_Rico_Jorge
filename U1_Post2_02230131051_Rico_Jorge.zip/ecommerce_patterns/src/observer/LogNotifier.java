package observer;
import java.time.LocalDateTime;

public class LogNotifier implements OrderObserver {
	
	@Override
	public void update(String orderId, String oldStatus, String newStatus) {
		System.out.println("["+LocalDateTime.now()+"] LOG: Pedido " + orderId +
				" paso de " + oldStatus + " a " + newStatus);
		
	}
}