package observer;

public class SMSNotifier implements OrderObserver {
	
	@Override
	public void update(String orderId, String oldStatus, String newStatus) {
		System.out.println("Mensaje SMS: El pedido " + orderId +
				" cambio de " + oldStatus +
				" a " + newStatus);
		
	}
}

