import observer.*;
import service.OrderService;
import strategy.*;

public class Main {

    public static void main(String[] args) {

        System.out.println("Inicio del sistema de E-COMMERCE");

        System.out.println("\nOrden regular");

        PricingStrategy regularStrategy = new RegularPricing();
        OrderService regularOrder =
                new OrderService("ORD-REG-001", regularStrategy);

        regularOrder.subscribe(new EmailNotifier());
        regularOrder.subscribe(new SMSNotifier());
        regularOrder.subscribe(new LogNotifier());

        System.out.println("\nCreando productos (Precio regular):");

        regularOrder.addProduct("ELECTRONICS", "Laptop", 2000);
        System.out.println("Producto: Laptop - Electronics - $2000");

        regularOrder.addProduct("CLOTHING", "Camisa", 80);
        System.out.println("Producto: Camisa - Clothing - $80");

        regularOrder.addProduct("FOOD", "Chocolate", 20);
        System.out.println("Producto: Chocolate - Food - $20");

        System.out.println("\nEstrategia aplicada: "
                + regularStrategy.getDescription());

        double totalRegular = regularOrder.calculateTotal();
        System.out.println("Total sin descuento: $" + totalRegular);

        System.out.println("\nEstados del pedido regular:");
        regularOrder.changeStatus("PROCESSING");
        regularOrder.changeStatus("SHIPPED");
        regularOrder.changeStatus("DELIVERED");

        System.out.println("\nOrden con descuento");

        int quantity = 12;
        PricingStrategy discountStrategy =
                new BulkPricing(quantity);

        OrderService discountOrder =
                new OrderService("ORD-DESC-001", discountStrategy);

        discountOrder.subscribe(new EmailNotifier());
        discountOrder.subscribe(new SMSNotifier());
        discountOrder.subscribe(new LogNotifier());

        System.out.println("\nCreando productos (Con descuento):");

        discountOrder.addProduct("ELECTRONICS", "Laptop", 2000);
        System.out.println("Producto: Laptop - Electronics - $2000");

        discountOrder.addProduct("CLOTHING", "Camisa", 80);
        System.out.println("Producto: Camisa - Clothing - $80");

        discountOrder.addProduct("FOOD", "Chocolate", 20);
        System.out.println("Producto: Chocolate - Food - $20");

        System.out.println("\nEstrategia aplicada: "
                + discountStrategy.getDescription());
        System.out.println("Cantidad de productos: " + quantity);

        double totalDiscount = discountOrder.calculateTotal();
        System.out.println("Total con descuento: $" + totalDiscount);

        System.out.println("\nEstados del pedido con descuento:");
        discountOrder.changeStatus("PROCESSING");
        discountOrder.changeStatus("SHIPPED");
        discountOrder.changeStatus("DELIVERED");

        System.out.println("\nRESUMEN FINAL");
        System.out.println("Total orden regular: $" + totalRegular);
        System.out.println("Total orden con descuento: $" + totalDiscount);

        System.out.println("\nFin del programa...");
    }
}