package model;

public class Food extends Product {
	
	private double calories;
	
	public Food(String name, double basePrice, double calories) {
		super(name, basePrice, "Food");
		this.calories = calories;
	}
	
	public double calculateShipping() { 
		return basePrice * 0.07; 
	}
	
	public String getDescription() {
	
		return name + " [Comida] - Calorias: " + calories;
	
	}
}
