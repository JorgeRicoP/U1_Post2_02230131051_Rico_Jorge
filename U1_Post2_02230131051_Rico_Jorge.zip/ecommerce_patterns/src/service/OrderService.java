package service;

import observer.OrderObserver;
import observer.OrderSubject;
import model.Product;
import factory.ProductFactory;
import strategy.PricingStrategy;

import java.util.ArrayList;
import java.util.List;

public class OrderService implements OrderSubject {

    private List<OrderObserver> observers = new ArrayList<>();
    private List<Product> products = new ArrayList<>();
    private PricingStrategy pricingStrategy;
    private String orderId;
    private String status;
    
    public OrderService(String orderId, PricingStrategy pricingStrategy) {
        this.orderId = orderId;
        this.pricingStrategy = pricingStrategy;
        this.status = "CREATED";
    }
    
    public void addProduct(String type, String name, double price) {
        Product product = ProductFactory.createProduct(type, name, price);
        products.add(product);
    }
    
    public double calculateTotal() {
        double total = 0;
        for (Product product : products) {
            total += pricingStrategy.calculateFinalPrice(product.getBasePrice());
        }
        return total;
    }
    
    public void changeStatus(String newStatus) {
        String oldStatus = this.status;
        this.status = newStatus;
        notifyObservers(orderId, oldStatus, newStatus);
    }
    
    @Override
    public void subscribe(OrderObserver observer) {
        observers.add(observer);
    }

    @Override
    public void unsubscribe(OrderObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String orderId, String oldStatus, String newStatus) {
        for (OrderObserver observer : observers) {
            observer.update(orderId, oldStatus, newStatus);
        }
    }
}   